document.addEventListener('DOMContentLoaded', function() {
    openTab(event, 'userDetailsTab'); // Open the default tab on page load
    populateUserTable(); // Populate the user table with dummy data (you can replace this with actual data)
});

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName('tabcontent');
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = 'none';
    }
    tablinks = document.getElementsByClassName('tablinks');
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(' active', '');
    }
    document.getElementById(tabName).style.display = 'block';
    evt.currentTarget.className += ' active';
}

function populateUserTable() {
    // Dummy data, replace this with actual data fetched from your database
    var users = [{
            id: 1,
            username: 'user1',
            email: 'user1@example.com'
        },
        {
            id: 2,
            username: 'user2',
            email: 'user2@example.com'
        },
        // Add more users as needed
    ];

    var table = document.getElementById('userTable');
    table.innerHTML = ''; // Clear existing table content

    // Create table header
    var header = table.createTHead();
    var row = header.insertRow(0);
    var headers = ['ID', 'Username', 'Email'];

    headers.forEach(function(headerText) {
        var th = document.createElement('th');
        var text = document.createTextNode(headerText);
        th.appendChild(text);
        row.appendChild(th);
    });

    // Create table body
    var body = table.createTBody();

    // Populate table rows with user data
    users.forEach(function(user) {
        var row = body.insertRow();
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);

        cell1.innerHTML = user.id;
        cell2.innerHTML = user.username;
        cell3.innerHTML = user.email;
    });
}

function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('userTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Index 1 corresponds to the Username column
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
}

function createAccount() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // You can perform further validation here before processing the form data

    // Dummy alert, replace this with your actual account creation logic
    alert('Account created successfully!\nUsername: ' + username + '\nPassword: ' + password);

    // Clear the form after account creation
    document.getElementById('accountCreationForm').reset();
}